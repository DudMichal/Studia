﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektPP_MichalDudek

{
    public partial class Form1 : Form
    {
        public static int przedzialy = 0;     //zmienne
        public static string daneWykresu = "";
        
        public Form1()
        {
            InitializeComponent();
        }
        OpenFileDialog op = new OpenFileDialog();  

        private void button1_Click(object sender, EventArgs e)
        {
            if (op.ShowDialog() == DialogResult.OK) // sprawdza czy kliknąleś ok
            {
                try
                {
                    richTextBox1.Clear();

                    string[] stringi = File.ReadAllText(op.FileName).Split(';');    // odzielenie ocen
                    double[] doublesy = Array.ConvertAll(stringi, new Converter<string, double>(Double.Parse)); //zamiana na double

                    int maxOcena = (int)Math.Ceiling(doublesy[0]), minOcena = (int)Math.Floor(doublesy[0]);

                    foreach (var ocena in doublesy)
                    {
                        if (maxOcena < (int)Math.Ceiling(ocena)) maxOcena = (int)Math.Ceiling(ocena);
                        if (minOcena > (int)Math.Floor(ocena)) minOcena = (int)Math.Floor(ocena); //porównywanie ocen, szukanie max i min
                    }
                    przedzialy = maxOcena - minOcena;      //ilość przedziałów
                    int[] iloscPrzedzialowych = new int[przedzialy]; // tablica

                    int j = 0;
                    foreach (var ocena in doublesy)
                    {
                        j = 0;

                        for (int i = minOcena + 1; i <= maxOcena; i++)
                        {
                            if (ocena > i - 1 && ocena <= i) iloscPrzedzialowych[j]++;
                            else if (ocena == 0) iloscPrzedzialowych[0]++;
                            j++;
                        }
                    }// liczy ile wyników
                    button2.Enabled = true;
                    j = minOcena + 1;
                    daneWykresu = "";

                    foreach (var ocena in iloscPrzedzialowych)
                    {
                        richTextBox1.AppendText(j - 1 + "-" + j + ": " + ocena + Environment.NewLine);// wypisywania zawartości
                        daneWykresu += j - 1 + "-" + j + ";" + ocena + ";"; //tworzy stringa do wypełnmenia wykresu
                        j++;
                    }
                    MessageBox.Show("Pilk załadowano pomyślnie");
                }
                catch
                {
                    MessageBox.Show("Podano złe dane, prosze podać inny plik", "Komunikat o błędzie");
                }
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 wykres = new Form2();
            wykres.ShowDialog(); // wyświetlanie wykresu
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string gdzie = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments); 

            using (StreamWriter outputFile = new StreamWriter(Path.Combine(gdzie, "wykresWynik.txt")))
            {
                outputFile.WriteLine("Rozkład: " + Environment.NewLine + richTextBox1.Text); //zapisywanie do pliku
            }
        }

    }
}
