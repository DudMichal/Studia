﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjektPP_MichalDudek
{
    public partial class Form2 : Form
    {
        
        private Random rnd = new Random();
        
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string[] dane = Form1.daneWykresu.Split(';');
            dane = dane.Take(dane.Count() - 1).ToArray();
            
            for (int i = 0; i < Form1.przedzialy * 2; i += 2)
            {
                chart1.Series.Add(dane[i]);
                chart1.Series[dane[i]].Color = Color.Blue;
                chart1.Series["Series1"].Points.AddXY(dane[i], dane[i + 1]);                  
            }
            for(int i = 0; i < Form1.przedzialy; i++)
            {
                checkedListBox1.Items.Add(i + "-" + (i + 1));
            }
            chart1.Titles.Add("Histogram ocen produktu"); //funkcja od wykresu
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            Color randomColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));

            BackColor = randomColor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for(int i=0;i<Form1.przedzialy+1; i++) chart1.Series[i].Color = Color.Red;
            button2.Visible = false;
            button4.Visible = true;
            checkedListBox1.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Form1.przedzialy+1; i++) 
            chart1.Series[i].IsVisibleInLegend = false;
            button3.Visible = false;
            button5.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Form1.przedzialy+1; i++) chart1.Series[i].Color = Color.Blue;
            button2.Visible = true;
            button4.Visible = false;
            checkedListBox1.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Form1.przedzialy+1; i++) 
            chart1.Series[i].IsVisibleInLegend = true;
            button3.Visible = true;
            button5.Visible = false;
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            

            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (checkedListBox1.GetItemChecked(i) == true)
                {
                    chart1.Series["Series1"].Points[i].Color = Color.Transparent;
                    
                }
                else
                {
                
                    chart1.Series["Series1"].Points[i].Color = Color.Blue;


                }
                
            }
        }
    }
}
